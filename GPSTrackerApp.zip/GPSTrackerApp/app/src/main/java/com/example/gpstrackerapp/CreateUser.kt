package com.example.gpstrackerapp

class CreateUser {
    lateinit var name: String
    lateinit var email: String
    lateinit var password: String
    lateinit var issharing: String
    lateinit var code: String
    lateinit var lat: String
    lateinit var lng: String
    lateinit var imageUrl: String

    public constructor()
    constructor(
        name: String,
        email: String,
        password: String,
        issharing: String,
        code: String,
        lat: String,
        lng: String,
        imageUrl: String
    ) {
        this.name = name
        this.email = email
        this.password = password
        this.issharing = issharing
        this.code = code
        this.lat = lat
        this.lng = lng
        this.imageUrl = imageUrl
    }
}