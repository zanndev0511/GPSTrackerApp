package com.example.gpstrackerapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    lateinit var auth : FirebaseAuth
    lateinit var e1: EditText
    lateinit var e2: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        e1 = findViewById(R.id.editTextTextEmailAddress)
        e2 = findViewById(R.id.editTextTextPassword)
        auth = FirebaseAuth.getInstance()
    }
    public fun login(v : View){
        auth.signInWithEmailAndPassword(e1.text.toString(), e2.text.toString())
            .addOnCompleteListener{task : Task<AuthResult> ->
                if (task.isSuccessful){
                    Toast.makeText(applicationContext,"User logged in successfully", Toast.LENGTH_LONG).show()
                    var myIntent: Intent = Intent(this, UserLocationMainActivity::class.java)
                    startActivity(myIntent)
                    finish()
                }
                else{
                    Toast.makeText(applicationContext,"Wrong email or password", Toast.LENGTH_LONG).show()
                }
            }
    }
}